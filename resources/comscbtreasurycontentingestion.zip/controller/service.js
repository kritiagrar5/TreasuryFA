sap.ui.define(["../lib/util"],function(n){"use strict";async function t(t,e,i,u){return await n.executeUnBoundInvokeAction(t,u,i,e)}return{createContent:t}});
//# sourceMappingURL=service.js.map